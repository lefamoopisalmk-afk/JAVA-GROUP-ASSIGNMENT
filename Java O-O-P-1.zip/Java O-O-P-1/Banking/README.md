# Console Banking System

This Java console application demonstrates an object-oriented banking system with savings and current accounts.

## Run

From the project root, compile and launch the `App` entry point:

```powershell
javac -d bin src\App.java src\banking\*.java
java -cp bin App
```

`App.java` delegates to `banking.BankingSystemMain`. The sample accounts are `1001` (SavingsAccount) and `2001` (CurrentAccount). Savings accounts maintain a M100 minimum balance and earn 5% interest. Current accounts have a M2,000 overdraft. The permitted loan limits are M100000 for savings and M20000 for current accounts.
