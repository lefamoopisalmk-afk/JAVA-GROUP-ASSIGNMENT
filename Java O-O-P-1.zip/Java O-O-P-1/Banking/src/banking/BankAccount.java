package banking;

// Abstract superclass: shared account data and required banking operations.
public abstract class BankAccount {
    // Encapsulation: account data stays private and changes only through account operations.
    private final String accountNumber;
    private final String accountHolder;
    private double balance;

    protected BankAccount(String accountNumber, String accountHolder, double openingBalance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = openingBalance;
    }

    public final String getAccountNumber() {
        return accountNumber;
    }

    public final String getAccountHolder() {
        return accountHolder;
    }

    public final double getBalance() {
        return balance;
    }

    public abstract boolean deposit(double amount);

    public abstract boolean withdraw(double amount);

    public abstract double calculateInterest();

    public abstract boolean requestLoan(double amount);

    protected abstract double getMinimumBalance();

    protected abstract double getOverdraftLimit();

    protected final boolean isPositiveAmount(double amount) {
        return Double.isFinite(amount) && amount > 0;
    }

    protected final boolean canChangeBalance(double change) {
        double updatedBalance = balance + change;
        return Double.isFinite(updatedBalance)
                && Math.abs(updatedBalance) <= Long.MAX_VALUE / 100.0;
    }

    protected final boolean changeBalance(double amount) {
        if (!canChangeBalance(amount)) {
            return false;
        }
        balance += amount;
        return true;
    }

    public final double getAvailableFunds() {
        return balance - getMinimumBalance() + getOverdraftLimit();
    }

    public final boolean transferTo(BankAccount recipient, double amount) {
        synchronized (BankAccount.class) {
            if (!isPositiveAmount(amount) || recipient == null || recipient == this
                    || amount > getAvailableFunds()
                    || !canChangeBalance(-amount)
                    || !recipient.canChangeBalance(amount)) {
                return false;
            }

            changeBalance(-amount);
            recipient.changeBalance(amount);
            return true;
        }
    }

    public final String getAccountType() {
        return getClass().getSimpleName();
    }

    public final void displayDetails() {
        System.out.println("Account: " + accountNumber
                + " | Holder: " + accountHolder
                + " | Type: " + getAccountType()
                + " | Balance: M" + balance
                + " | Available: M" + getAvailableFunds());
    }

}
