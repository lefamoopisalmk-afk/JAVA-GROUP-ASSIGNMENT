package banking;

import java.util.Scanner;

public final class BankingSystemMain {
    private static final double MAXIMUM_BALANCE = Long.MAX_VALUE / 100.0;

    private final Scanner scanner = new Scanner(System.in);
    // Polymorphism: one BankAccount collection holds both account subclasses.
    private final BankAccount[] accounts = {
        new SavingsAccount("9010", "Lefa Moopisa", 5000.00),
        new CurrentAccount("9020", "Refuoe Lechesa", 3000.00)
    };

    public static void main(String[] args) {
        BankingSystemMain bankingSystem = new BankingSystemMain();
        bankingSystem.run();
    }

    private void run() {
        System.out.println("Welcome to the Console Banking System.");
        boolean running = true;
        while (running) {
            displayMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    displayAllAccounts();
                    break;
                case "2":
                    performDeposit();
                    break;
                case "3":
                    performWithdrawal();
                    break;
                case "4":
                    performTransfer();
                    break;
                case "5":
                    calculateInterest();
                    break;
                case "6":
                    requestLoan();
                    break;
                case "7":
                    displayAccountDetails();
                    break;
                case "8":
                    running = false;
                    System.out.println("Thank you for using the Console Banking System.");
                    break;
                default:
                    System.out.println("Invalid menu choice. Enter a number from 1 to 8.");
            }
        }
    }

    private void displayMenu() {
        System.out.println();
        System.out.println("1. Display all accounts");
        System.out.println("2. Deposit money");
        System.out.println("3. Withdraw money");
        System.out.println("4. Transfer money");
        System.out.println("5. Calculate interest");
        System.out.println("6. Request bank loan");
        System.out.println("7. Display account details");
        System.out.println("8. Exit");
        System.out.print("Choose an option: ");
    }

    private void displayAllAccounts() {
        for (int i = 0; i < accounts.length; i++) {
            accounts[i].displayDetails();
        }
    }

    private void performDeposit() {
        BankAccount account = promptForAccount("deposit into");
        double amount = promptForAmount();
        if (amount > MAXIMUM_BALANCE - account.getBalance()) {
            System.out.println("The resulting balance is too large.");
            return;
        }
        if (!account.deposit(amount)) {
            System.out.println("The deposit could not be completed.");
            return;
        }
        System.out.println("Deposit successful.");
    }

    private void performWithdrawal() {
        BankAccount account = promptForAccount("withdraw from");
        double amount = promptForAmount();
        if (amount > account.getAvailableFunds()
                || (account instanceof SavingsAccount
                && account.getBalance() - amount < 100.00)) {
            System.out.println("Insufficient available funds.");
            return;
        }
        if (!account.withdraw(amount)) {
            System.out.println("The withdrawal could not be completed.");
            return;
        }
        System.out.println("Withdrawal successful.");
    }

    private void performTransfer() {
        BankAccount source = promptForAccount("transfer from");
        BankAccount destination = promptForAccount("transfer to");
        double amount = promptForAmount();
        if (source == destination) {
            System.out.println("Choose a different destination account.");
            return;
        }
        if (amount > source.getAvailableFunds()) {
            System.out.println("Insufficient available funds.");
            return;
        }
        if (amount > MAXIMUM_BALANCE - destination.getBalance()) {
            System.out.println("The destination balance would be too large.");
            return;
        }
        if (!source.transferTo(destination, amount)) {
            System.out.println("The transfer could not be completed.");
            return;
        }
        System.out.println("Transfer successful.");
    }

    private void calculateInterest() {
        BankAccount account = promptForAccount("calculate interest for");
        double interest = account.calculateInterest();
        System.out.println("Interest credited: M" + interest);
    }

    private void requestLoan() {
        BankAccount account = promptForAccount("request a loan for");
        double amount = promptForAmount();
        double loanLimit = account instanceof SavingsAccount ? 100000.00 : 20000.00;
        if (amount > loanLimit) {
            System.out.println("The loan limit for this account is M" + loanLimit + ".");
            return;
        }
        if (!account.requestLoan(amount)) {
            System.out.println("The loan could not be completed.");
            return;
        }
        System.out.println("Loan approved and credited to the account.");
    }

    private void displayAccountDetails() {
        promptForAccount("display").displayDetails();
    }

    private BankAccount promptForAccount(String purpose) {
        while (true) {
            System.out.println("Enter the account number to " + purpose + ":");
            displayAccountNumbers();
            System.out.print("Account number: ");
            String accountNumber = scanner.nextLine().trim();
            for (int i = 0; i < accounts.length; i++) {
                if (accounts[i].getAccountNumber().equals(accountNumber)) {
                    return accounts[i];
                }
            }
            System.out.println("Account number was not found. Please try again.");
        }
    }

    private void displayAccountNumbers() {
        for (int i = 0; i < accounts.length; i++) {
            System.out.println(accounts[i].getAccountNumber() + " - " + accounts[i].getAccountHolder()
                    + " (" + accounts[i].getAccountType() + ")");
        }
    }

    private double promptForAmount() {
        while (true) {
            System.out.print("Amount (M): ");
            String input = scanner.nextLine().trim();
            boolean validAmount = !input.isEmpty()
                    && input.charAt(0) >= '0' && input.charAt(0) <= '9';
            boolean decimalPointSeen = false;
            for (int i = 0; i < input.length(); i++) {
                char character = input.charAt(i);
                if (character == '.' && !decimalPointSeen) {
                    decimalPointSeen = true;
                } else if (character < '0' || character > '9') {
                    validAmount = false;
                }
            }
            if (validAmount && input.charAt(input.length() - 1) != '.') {
                double amount = Double.parseDouble(input);
                if (Double.isFinite(amount) && amount > 0) {
                    return amount;
                }
            }
            System.out.println("Enter a valid amount greater than zero.");
        }
    }
}
