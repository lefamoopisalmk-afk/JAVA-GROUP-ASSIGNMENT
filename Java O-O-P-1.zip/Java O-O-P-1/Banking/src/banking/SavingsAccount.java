package banking;

// Inheritance and interface implementation: a savings account is a bank account and can request loans.
public class SavingsAccount extends BankAccount {
    private static final double MINIMUM_BALANCE = 100.00;
    private static final double ANNUAL_INTEREST_RATE = 0.05;
    private static final double LOAN_LIMIT = 100000.00;

    public SavingsAccount(String accountNumber, String accountHolder, double openingBalance) {
        super(accountNumber, accountHolder, openingBalance);
    }

    @Override
    public boolean deposit(double amount) {
        return isPositiveAmount(amount) && changeBalance(amount);
    }

    @Override
    public boolean withdraw(double amount) {
        if (!isPositiveAmount(amount)) {
            return false;
        }
        if (getBalance() - amount < MINIMUM_BALANCE) {
            return false;
        }
        return changeBalance(-amount);
    }

    // Overriding: savings accounts earn and receive 5% annual interest.
    @Override
    public double calculateInterest() {
        double interest = getBalance() * ANNUAL_INTEREST_RATE;
        if (changeBalance(interest)) {
            return interest;
        }
        return 0;
    }

    // Polymorphic account rules are supplied by each concrete subclass.
    @Override
    protected double getMinimumBalance() {
        return MINIMUM_BALANCE;
    }

    @Override
    protected double getOverdraftLimit() {
        return 0;
    }

    @Override
    public boolean requestLoan(double amount) {
        return isPositiveAmount(amount) && amount <= LOAN_LIMIT && changeBalance(amount);
    }
}
