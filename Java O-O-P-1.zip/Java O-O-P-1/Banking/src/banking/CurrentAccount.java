package banking;

// Inheritance and interface implementation: a current account is a bank account and can request loans.
public class CurrentAccount extends BankAccount {
    private static final double OVERDRAFT_LIMIT = 2000.00;
    private static final double LOAN_LIMIT = 20000.00;

    public CurrentAccount(String accountNumber, String accountHolder, double openingBalance) {
        super(accountNumber, accountHolder, openingBalance);
    }

    @Override
    public boolean deposit(double amount) {
        return isPositiveAmount(amount) && changeBalance(amount);
    }

    @Override
    public boolean withdraw(double amount) {
        if (!isPositiveAmount(amount) || amount > getAvailableFunds()) {
            return false;
        }
        return changeBalance(-amount);
    }

    // Overriding: current accounts earn no interest.
    @Override
    public double calculateInterest() {
        return 0.0;
    }

    @Override
    protected double getMinimumBalance() {
        return 0;
    }

    @Override
    protected double getOverdraftLimit() {
        return OVERDRAFT_LIMIT;
    }

    @Override
    public boolean requestLoan(double amount) {
        return isPositiveAmount(amount) && amount <= LOAN_LIMIT && changeBalance(amount);
    }
}
