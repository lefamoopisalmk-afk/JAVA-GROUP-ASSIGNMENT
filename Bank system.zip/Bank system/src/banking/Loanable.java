package banking;

// Abstraction
public interface Loanable 
{
    void requestLoan(double amount);
}
