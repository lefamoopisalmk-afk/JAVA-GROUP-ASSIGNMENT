import banking.BankingSystemMain;

public final class App 
{
    private App() {
    }

    // Application entry point
    public static void main(String[] args) 
    {
        BankingSystemMain.main(args);
    }
}
