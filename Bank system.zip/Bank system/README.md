# Console Banking System

This Java console application demonstrates an object-oriented banking system with savings and current accounts.

## Run

From the project root, compile and launch the `App` entry point:

```powershell
javac -d bin src\App.java src\banking\*.java
java -cp bin App
```

`App.java` is the application entry point and delegates to `banking.BankingSystemMain`. In VS Code, open `src\App.java` and choose **Run** above its `main` method, or use the **Run App** launch configuration. The sample accounts are `9010` (SavingsAccount) and `9020` (CurrentAccount). Savings accounts maintain a M100 minimum balance and earn 5% interest. Current accounts have a M2,000 overdraft. The permitted loan limits are M100000 for savings and M20000 for current accounts.

Successful and rejected banking transactions are appended with timestamps to `transactions.txt` in the application's working directory. If the log file cannot be written, the app reports the error without stopping the banking session.
